export const API_URLS = {
  register: "/register",
  login: "/login",
  createResidence: "/create-residence",
  residences: "/residences",
  user: "/user",
  home: "/home",
  updateProfile: "/update-profile",
  contactUs: "/contact-us",
  addReview: "/add-review",
  getReview: "/reviews",
};
