//regex
//constant values