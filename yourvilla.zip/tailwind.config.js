/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  darkMode:'class',
  theme: {
    extend: {
      colors: {
        primary: "#9B59B6",
        secondary: "#5295EC",
      },
      boxShadow: {
        // card: "0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24)",
        card:"0 25px 50px -12px rgb(0 0 0 / 0.25)"
      },
      backgroundImage: {
        homeBackgroud: "url('https://assets.architecturaldigest.in/photos/60083e76274aca243711c3a4/16:9/w_2560%2Cc_limit/ghaziabad-uttar-pradesh-homes-photos-1366x768.jpg')",
      },
    },
  },
  plugins: [],
};
